<?php
namespace Willoway\RGI\billing;

use Willoway\RGI\licensing\LicenseService;

class StripeWebhook {
    public function handle(array $event): array {
        if (($event['type'] ?? '') === 'checkout.session.completed') {
            $license = (new LicenseService())->generate(
                $event['data']['object']['metadata']['organization_id'] ?? 'pending-org',
                $event['data']['object']['metadata']['product_code'] ?? 'OPS-A'
            );
            return ['action' => 'license_generated', 'license' => $license];
        }
        return ['action' => 'ignored'];
    }
}
