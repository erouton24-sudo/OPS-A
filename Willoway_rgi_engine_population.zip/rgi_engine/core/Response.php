<?php
namespace Willoway\RGI\core;

class Response {
    public static function ok(array $data = []): void { rgi_json(['ok' => true, 'data' => $data]); }
    public static function error(string $message, int $status = 400): void { rgi_json(['ok' => false, 'error' => $message], $status); }
}
