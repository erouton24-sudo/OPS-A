<?php
namespace Willoway\RGI\core;

use PDO;
use PDOException;

class Database {
    public static function pdo(): PDO {
        $cfg = rgi_config()['db'];
        $dsn = "mysql:host={$cfg['host']};dbname={$cfg['name']};charset=utf8mb4";
        try {
            return new PDO($dsn, $cfg['user'], $cfg['pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            rgi_json(['error' => 'Database connection failed'], 500);
        }
    }
}
