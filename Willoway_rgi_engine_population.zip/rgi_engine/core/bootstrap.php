<?php
// Willoway RGI bootstrap
spl_autoload_register(function ($class) {
    $base = __DIR__ . '/../';
    $file = $base . str_replace('Willoway\\RGI\\', '', $class) . '.php';
    $file = str_replace('\\', '/', $file);
    if (file_exists($file)) {
        require_once $file;
    }
});

function rgi_config(): array {
    static $config = null;
    if ($config === null) {
        $config = require __DIR__ . '/../config/config.php';
    }
    return $config;
}

function rgi_json(array $payload, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}
