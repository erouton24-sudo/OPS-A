<?php
namespace Willoway\RGI\admin;

class AdminService {
    public function dashboardSummary(): array {
        return [
            'users' => 0,
            'organizations' => 0,
            'active_licenses' => 0,
            'monthly_recurring_revenue' => 0,
            'status' => 'scaffold'
        ];
    }
}
