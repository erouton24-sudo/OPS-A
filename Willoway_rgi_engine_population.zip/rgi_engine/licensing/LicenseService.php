<?php
namespace Willoway\RGI\licensing;

class LicenseService {
    public function generate(string $organizationId, string $productCode, string $term = '+1 year'): array {
        return [
            'license_id' => bin2hex(random_bytes(16)),
            'organization_id' => $organizationId,
            'product_code' => $productCode,
            'status' => 'active',
            'expires_at' => date('c', strtotime($term)),
        ];
    }

    public function validate(array $license): bool {
        return ($license['status'] ?? '') === 'active' && strtotime($license['expires_at'] ?? '1970-01-01') > time();
    }
}
