<?php
return [
    'app_name' => getenv('APP_NAME') ?: 'Willoway RGI Engine',
    'env' => getenv('APP_ENV') ?: 'production',
    'db' => [
        'host' => getenv('DB_HOST') ?: 'localhost',
        'name' => getenv('DB_NAME') ?: 'willoway',
        'user' => getenv('DB_USER') ?: '',
        'pass' => getenv('DB_PASS') ?: '',
    ],
    'jwt_secret' => getenv('JWT_SECRET') ?: '',
    'stripe_secret_key' => getenv('STRIPE_SECRET_KEY') ?: '',
    'stripe_webhook_secret' => getenv('STRIPE_WEBHOOK_SECRET') ?: '',
    'crm_api_key' => getenv('CRM_API_KEY') ?: '',
];
