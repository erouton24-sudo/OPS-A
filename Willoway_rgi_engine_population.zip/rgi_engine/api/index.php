<?php
require_once __DIR__ . '/../core/bootstrap.php';

use Willoway\RGI\auth\AuthService;
use Willoway\RGI\marketplace\ProductCatalog;
use Willoway\RGI\licensing\LicenseService;
use Willoway\RGI\billing\StripeWebhook;
use Willoway\RGI\admin\AdminService;

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$body = json_decode(file_get_contents('php://input'), true) ?: [];

if ($method === 'GET' && str_ends_with($path, '/health')) {
    rgi_json(['ok' => true, 'engine' => 'Willoway RGI', 'status' => 'online']);
}

if ($method === 'POST' && str_ends_with($path, '/auth/login')) {
    rgi_json(['ok' => true, 'data' => (new AuthService())->login($body['email'] ?? '', $body['password'] ?? '')]);
}

if ($method === 'GET' && str_ends_with($path, '/marketplace/products')) {
    rgi_json(['ok' => true, 'data' => (new ProductCatalog())->all()]);
}

if ($method === 'POST' && str_ends_with($path, '/licenses')) {
    rgi_json(['ok' => true, 'data' => (new LicenseService())->generate($body['organization_id'] ?? 'pending-org', $body['product_code'] ?? 'OPS-A')]);
}

if ($method === 'POST' && str_ends_with($path, '/billing/stripe-webhook')) {
    rgi_json(['ok' => true, 'data' => (new StripeWebhook())->handle($body)]);
}

if ($method === 'GET' && str_ends_with($path, '/admin/summary')) {
    rgi_json(['ok' => true, 'data' => (new AdminService())->dashboardSummary()]);
}

rgi_json(['ok' => false, 'error' => 'Route not found', 'path' => $path], 404);
