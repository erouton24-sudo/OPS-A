# Willoway RGI Engine

This folder is the private operational engine for the Willoway Phase 3 platform. Keep it outside `public_html` unless your hosting plan requires otherwise.

## Purpose
- Authentication and role checks
- License issuance and status tracking
- Subscription and Stripe webhook handling
- Marketplace product registry
- CRM lead/customer sync stubs
- Admin utilities

## Deployment on IONOS
1. Upload the entire `rgi_engine/` folder to the webspace root beside `public_html/`.
2. Keep `config/.env.example` as a template only. Create `config/.env` manually with real secrets.
3. Import `database/schema.sql` into your MySQL/MariaDB database.
4. If exposing API endpoints from `public_html/api`, include/require `../rgi_engine/api/index.php` from the public route.
5. Do not expose `config/`, `core/`, `logs/`, or `database/` directly to the browser.

## Current Status
This is a Phase 3 scaffold: stable folder structure, database schema, PHP service stubs, and API routing. It is not a completed SaaS product until connected to a database, Stripe account, CRM, and secured production authentication.
