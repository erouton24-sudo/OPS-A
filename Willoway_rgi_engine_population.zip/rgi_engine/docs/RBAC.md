# Willoway RBAC

Roles:
- SuperAdmin
- PlatformAdmin
- SalesAdmin
- SupportAdmin
- CustomerAdmin
- CustomerUser

Recommended rule: customer organizations should only see their own users, licenses, subscriptions, and products.
