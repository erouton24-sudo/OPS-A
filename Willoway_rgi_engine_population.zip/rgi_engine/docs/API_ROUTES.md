# API Routes

- GET /health
- POST /auth/login
- GET /marketplace/products
- POST /licenses
- POST /billing/stripe-webhook
- GET /admin/summary

Expose these routes through a controlled public endpoint in `public_html/api/` rather than directly exposing the engine folder.
