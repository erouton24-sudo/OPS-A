<?php
namespace Willoway\RGI\auth;

class AuthService {
    public function login(string $email, string $password): array {
        // Replace with password_hash/password_verify + database lookup.
        return [
            'email' => $email,
            'role' => 'CustomerUser',
            'token' => base64_encode($email . '|' . time())
        ];
    }

    public function requireRole(array $user, array $allowedRoles): bool {
        return in_array($user['role'] ?? '', $allowedRoles, true);
    }
}
