<?php
namespace Willoway\RGI\marketplace;

class ProductCatalog {
    public function all(): array {
        return [
            ['code' => 'OPS-A', 'name' => 'OPS-A Strategic Operating License', 'type' => 'subscription'],
            ['code' => 'CODEX', 'name' => 'Willoway Strategic Codex Access', 'type' => 'subscription'],
            ['code' => 'CERT', 'name' => 'Willoway Practitioner Certification', 'type' => 'training'],
        ];
    }
}
