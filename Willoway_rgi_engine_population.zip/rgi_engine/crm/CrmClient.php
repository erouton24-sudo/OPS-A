<?php
namespace Willoway\RGI\crm;

class CrmClient {
    public function syncLead(array $lead): array {
        // Connect to HubSpot, Zoho, Salesforce, or custom CRM later.
        return ['synced' => false, 'queued' => true, 'lead' => $lead];
    }
}
