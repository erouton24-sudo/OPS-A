=== Swift OPS-A : IONOS Deployment Guide ===

This package contains the Split-Directory Architecture required to securely run the Replayable Governance Intelligence (RGI) engine on IONOS.

STEP 1: DATABASE SETUP
1. Log into IONOS -> Databases.
2. Create a new MySQL/MariaDB database.
3. Open phpMyAdmin.
4. Import the `schema.sql` file included in this zip to create the required ledger tables.

STEP 2: FILE UPLOAD & DIRECTORY MAPPING
Warning: Do not just dump these folders into `public_html`.
1. Open IONOS Webspace Explorer (File Manager) or connect via SFTP.
2. Upload the entire extracted folder structure to the ROOT of your server (one level ABOVE `public_html`).
3. Move the contents of this package's `public_html` folder INTO your server's actual `public_html` folder.
   - Example Server Path: 
     /
     ├── /rgi_engine/  <-- (Secure, Private)
     ├── /data_vault/  <-- (Secure, Private)
     └── /public_html/ <-- (Public Web Root containing index.php)

STEP 3: CONFIGURATION
1. Edit `/rgi_engine/config/config.php`.
2. Replace DB_HOST, DB_NAME, DB_USER, and DB_PASS with the IONOS credentials created in Step 1.

STEP 4: PERMISSIONS
1. Inside IONOS File Manager, right click `/rgi_engine/config/config.php`.
2. Change permissions to `600` (Owner read/write only) to protect your database passwords.

STEP 5: VERIFICATION
1. Navigate to www.swiftopsa.com.
2. You will see the RGI Gateway.
3. Enter the test license key: DEMO-ENTERPRISE-2026
4. If successful, your platform is correctly communicating with the secured operational memory ledger.
