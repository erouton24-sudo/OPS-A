<?php
// FILE: /rgi_engine/licensing/gateway.php
// PURPOSE: Commercial Licensing Verification & Execution Lock

require_once __DIR__ . '/../config/config.php';

function verifyEnterpriseLicense($license_key) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT client_name, tier, is_active, expiration_date FROM opsa_licenses WHERE license_key = :license_key LIMIT 1");
    $stmt->execute(['license_key' => $license_key]);
    $license = $stmt->fetch();

    if (!$license) {
        return ['status' => 'DENIED', 'message' => 'Invalid License Key. OPS-A Runtime execution halted.'];
    }

    if ((int)$license['is_active'] !== 1) {
        return ['status' => 'DENIED', 'message' => 'License has been deactivated by Willoway administration.'];
    }

    $current_date = new DateTime();
    $expiration_date = new DateTime($license['expiration_date']);

    if ($current_date > $expiration_date) {
        return ['status' => 'DENIED', 'message' => 'Subscription Expired. Renew enterprise licensing to resume Operational Memory access.'];
    }

    return [
        'status' => 'AUTHORIZED',
        'client' => $license['client_name'],
        'tier' => $license['tier'],
        'message' => 'Licensing verified. Governance Runtime initialized.'
    ];
}
?>