<?php
// FILE: /rgi_engine/config/config.php
// PURPOSE: Secure Database Connection for OPS-A Framework

// IONOS Database Credentials (Update these via IONOS Control Panel -> Database)
define('DB_HOST', 'db.ionos.com'); // Replace with your IONOS DB Host
define('DB_NAME', 'your_ionos_database_name'); // Replace with your DB Name
define('DB_USER', 'your_ionos_db_username'); // Replace with your DB Username
define('DB_PASS', 'your_ionos_secure_password'); // Replace with your DB Password

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    error_log("Database Connection Failed: " . $e->getMessage());
    die("System Execution Halted: Governance framework cannot connect to the operational memory ledger. Check configuration.");
}
?>