-- Willoway OPS-A Foundation Schema
-- Import this via IONOS phpMyAdmin

CREATE TABLE IF NOT EXISTS opsa_actors (
    actor_id VARCHAR(50) PRIMARY KEY,
    actor_name VARCHAR(100) NOT NULL,
    role_classification VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS opsa_events (
    event_id VARCHAR(50) PRIMARY KEY,
    actor_id VARCHAR(50) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_description TEXT NOT NULL,
    continuity_impact DECIMAL(5,2) DEFAULT 0.00,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (actor_id) REFERENCES opsa_actors(actor_id)
);

CREATE TABLE IF NOT EXISTS opsa_telemetry (
    telemetry_id INT AUTO_INCREMENT PRIMARY KEY,
    system_state VARCHAR(50) NOT NULL,
    resilience_score DECIMAL(5,2) NOT NULL,
    drift_detected BOOLEAN DEFAULT FALSE,
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS opsa_licenses (
    license_key VARCHAR(100) PRIMARY KEY,
    client_name VARCHAR(100) NOT NULL,
    tier VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    expiration_date DATE NOT NULL
);

-- Insert a test license for your first deployment
INSERT INTO opsa_licenses (license_key, client_name, tier, is_active, expiration_date) 
VALUES ('DEMO-ENTERPRISE-2026', 'Willoway Initial Pilot', 'Enterprise', TRUE, '2026-12-31');
