<?php
// FILE: /public_html/index.php
// PURPOSE: Public-facing licensing portal

$message = '';
$auth_success = false;
$client_name = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['license_key'])) {
    // Determine path based on deployment (adjust path if running locally vs on IONOS root)
    $gateway_path = realpath(__DIR__ . '/../rgi_engine/licensing/gateway.php');
    
    if (file_exists($gateway_path)) {
        require_once $gateway_path;
        $auth_response = verifyEnterpriseLicense(trim($_POST['license_key']));
        
        if ($auth_response['status'] === 'AUTHORIZED') {
            $auth_success = true;
            $client_name = $auth_response['client'];
            $message = $auth_response['message'];
        } else {
            $message = "Access Denied: " . $auth_response['message'];
        }
    } else {
        $message = "System Error: RGI Engine not found. Ensure split-directory architecture is configured correctly.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Swift OPS-A | Enterprise Gateway</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background-color: #0F172A; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; font-family: 'Inter', sans-serif; }
        .login-card { background: #1E293B; padding: 40px; border-radius: 8px; border: 1px solid #334155; box-shadow: 0 10px 25px rgba(0,0,0,0.5); width: 100%; max-width: 450px; text-align: center; }
        h1 { color: #FFFFFF; font-size: 24px; margin-bottom: 10px; }
        p { color: #94A3B8; font-size: 14px; margin-bottom: 30px; }
        input[type="text"] { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #334155; background: #0F172A; color: #FFFFFF; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #3B82F6; color: #FFFFFF; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        button:hover { background: #2563EB; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; font-size: 14px; text-align: left; }
        .alert-error { background: rgba(239, 68, 68, 0.1); border: 1px solid #EF4444; color: #EF4444; }
        .alert-success { background: rgba(16, 185, 129, 0.1); border: 1px solid #10B981; color: #10B981; }
        .dashboard-link { display: inline-block; margin-top: 20px; color: #3B82F6; text-decoration: none; }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>Swift OPS-A Platform</h1>
        <p>Replayable Governance Intelligence Gateway</p>
        
        <?php if ($message && !$auth_success): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($auth_success): ?>
            <div class="alert alert-success">
                <strong>Authorization Successful</strong><br>
                Welcome, <?php echo htmlspecialchars($client_name); ?>.<br>
                <?php echo htmlspecialchars($message); ?>
            </div>
            <a href="#" class="dashboard-link">Initialize Operational Memory Workspace &rarr;</a>
        <?php else: ?>
            <form method="POST" action="">
                <input type="text" name="license_key" placeholder="Enter Enterprise License Key" required>
                <button type="submit">Authenticate Session</button>
            </form>
            <p style="margin-top: 20px; font-size: 12px; color: #475569;">Trial Key: DEMO-ENTERPRISE-2026</p>
        <?php endif; ?>
    </div>
</body>
</html>
